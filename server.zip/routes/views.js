const router = require("express").Router();
const viewsController = require("../controllers/viewsController");

module.exports = router;
